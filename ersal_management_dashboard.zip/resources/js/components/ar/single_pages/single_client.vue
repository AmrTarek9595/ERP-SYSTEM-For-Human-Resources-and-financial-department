<template>

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    
    
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
    <div class="container-fluid py-1 px-3">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Employee</li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Single Client Page</li>
    </ol>
    <h6 class="font-weight-bolder mb-0">Client</h6>
    </nav>
    <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
    <div class="ms-md-auto pe-md-3 d-flex align-items-center">
    <div class="input-group">
    <span class="input-group-text text-body"><i class="fa-solid fa-magnifying-glass"></i></span>
    <input type="text" class="form-control" placeholder="Type here...">
    </div>
    </div>
    <ul class="navbar-nav  justify-content-end">
    <li class="nav-item d-flex align-items-center">
    <a class="btn btn-outline-primary btn-sm mb-0 me-3" target="_blank" href="https://www.creative-tim.com/builder?ref=navbar-soft-ui-dashboard">Online Employee</a>
    </li>
    <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
    <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
    <div class="sidenav-toggler-inner">
    <i class="sidenav-toggler-line"></i>
    <i class="sidenav-toggler-line"></i>
    <i class="sidenav-toggler-line"></i>
    </div>
    </a>
    </li>
    
    
    </ul>
    </div>
    </div>
    </nav>
    <div class="row container-fluid py-4">
    
    
    
    <div class="col-xl-3 col-sm-6">
    <div class="card">
    <div class="card-body p-3">
    <div class="row">
    <div class="col-4 text-start">
    <div class="icon icon-shape shadow text-center border-radius-md">
        <svg version="1.1" width="80" height="50" id="fi_476863" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#5A4146;" d="M371.613,227.096v5.795c0,7.101,1.145,14.155,3.39,20.891l13.126,39.378h24.774v-90.839h-16.516
	C382.705,202.322,371.613,213.413,371.613,227.096z"></path>
<path style="fill:#694B4B;" d="M484.684,244.251l-13.974,48.91l-66.065-57.806c-9.122,0-16.516-7.395-16.516-16.516l0,0
	c0-13.682,11.092-24.774,24.774-24.774h57.806c9.122,0,16.516,7.395,16.516,16.516v15.522
	C487.226,232.24,486.37,238.348,484.684,244.251z"></path>
<rect x="404.64" y="317.94" style="fill:#E6AF78;" width="49.548" height="36.549"></rect>
<path style="fill:#D29B6E;" d="M404.645,333.104c7.659,3.112,16.011,4.864,24.774,4.864s17.115-1.752,24.774-4.864v-15.169h-49.548
	L404.645,333.104L404.645,333.104z"></path>
<path style="fill:#D5DCED;" d="M494.031,349.351l-39.84-11.382l-24.772,16.439l-24.774-16.44l-39.838,11.383
	c-10.636,3.039-17.968,12.76-17.968,23.821v60.376c0,4.561,3.697,8.258,8.258,8.258h148.645c4.561,0,8.258-3.697,8.258-8.258
	v-60.376C512,362.11,504.667,352.39,494.031,349.351z"></path>
<polygon style="fill:#AFB9D2;" points="437.677,441.805 421.161,441.805 425.29,354.484 433.548,354.484 "></polygon>
<path style="fill:#F0C087;" d="M429.419,326.193L429.419,326.193c-27.365,0-49.548-22.184-49.548-49.548v-9.675
	c0-4.38,1.74-8.581,4.837-11.679l14.975-14.975c3.171-3.171,7.507-4.994,11.989-4.853c26.398,0.833,49.764,6.488,62.537,18.963
	c3.127,3.054,4.759,7.326,4.759,11.696v10.523C478.968,304.01,456.784,326.193,429.419,326.193z"></path>
<path style="fill:#E6AF78;" d="M404.645,269.018c0-9.526,8-17.098,17.507-16.492c16.671,1.064,41.409,3.85,56.586,11.15
	c-0.495-3.484-1.992-6.773-4.529-9.251c-12.773-12.475-36.139-18.13-62.537-18.963l-0.001,0.001v-0.001
	c-4.481-0.141-8.818,1.683-11.988,4.853l-14.974,14.974c-3.098,3.097-4.838,7.298-4.838,11.679v9.675
	c0,22.596,15.141,41.621,35.82,47.579c-6.883-8.492-11.045-19.272-11.045-31.063L404.645,269.018L404.645,269.018z"></path>
<path style="fill:#C7CFE2;" d="M478.968,397.779c0-6.571,2.61-12.872,7.256-17.518l21.257-21.257
	c2.841,4.061,4.519,8.95,4.519,14.169v60.376c0,4.561-3.697,8.258-8.258,8.258h-24.774L478.968,397.779L478.968,397.779z"></path>
<path style="fill:#959CB5;" d="M433.548,371h-8.258c-2.28,0-4.129-1.849-4.129-4.129v-12.387h16.516v12.387
	C437.677,369.151,435.829,371,433.548,371z"></path>
<g>
	<path style="fill:#C7CFE2;" d="M429.419,354.409L415.422,365.1c-2.411,1.842-5.897,1.104-7.354-1.558l-12.556-22.93l5.054-7.709
		c1.121-1.71,3.51-2.001,5.009-0.611L429.419,354.409z"></path>
	<path style="fill:#C7CFE2;" d="M429.419,354.409l13.997,10.692c2.411,1.842,5.897,1.104,7.354-1.558l12.556-22.93l-5.054-7.709
		c-1.121-1.71-3.51-2.001-5.009-0.611L429.419,354.409z"></path>
</g>
<path style="fill:#5A4146;" d="M147.822,322.745c-7.057-18.698-12.654-50.841-13.863-67.576
	c-2.3-31.846-26.299-57.806-58.741-57.806s-56.441,25.961-58.741,57.806c-1.209,16.734-6.806,48.878-13.863,67.576
	c-1.555,4.122,0.24,8.667,4.299,10.507c7.562,3.427,23.685,10.141,43.13,12.756h50.349c19.354-2.621,35.59-9.339,43.13-12.756
	C147.582,331.412,149.377,326.867,147.822,322.745z"></path>
<path style="fill:#694B4B;" d="M143.523,333.253c4.058-1.84,5.854-6.385,4.298-10.507c-7.056-18.698-12.654-50.841-13.862-67.576
	c-2.299-31.846-26.299-57.806-58.74-57.806c-0.082,0-0.163,0-0.245,0.001c-24.893,0.101-33.69,34.05-12.261,46.717
	c1.287,0.761,2.112,1.127,2.112,1.127l18.769,100.8h16.799C119.747,343.386,135.983,336.669,143.523,333.253z"></path>
<path style="fill:#E6AF78;" d="M134.95,362.588l-26.724-13.361c-5.596-2.798-9.131-8.518-9.13-14.774l0.002-24.775h-49.55v24.776
	c0,6.256-3.534,11.974-9.13,14.772l-26.724,13.362C5.301,366.784,0,375.362,0,384.745v48.802c0,4.56,3.697,8.258,8.258,8.258
	h132.129c4.561,0,8.258-3.698,8.258-8.258v-48.801C148.645,375.362,143.343,366.784,134.95,362.588z"></path>
<path style="fill:#D29B6E;" d="M74.323,342.709c8.892,0,17.409-1.833,25.217-5.096c-0.205-1.041-0.444-2.076-0.444-3.161
	l0.002-24.775h-49.55v24.776c0,1.091-0.239,2.131-0.446,3.176C56.915,340.875,65.428,342.709,74.323,342.709z"></path>
<path style="fill:#D5DCED;" d="M134.95,362.588l-19.038-9.519c-8.828,13.632-24.139,22.673-41.589,22.673
	s-32.762-9.041-41.59-22.674l-19.038,9.52C5.302,366.784,0,375.362,0,384.745v48.802c0,4.561,3.697,8.258,8.258,8.258h132.129
	c4.561,0,8.258-3.697,8.258-8.258v-48.801C148.645,375.362,143.343,366.784,134.95,362.588z"></path>
<path style="fill:#F0C087;" d="M74.323,326.193L74.323,326.193c-25.192,0-45.992-18.8-49.137-43.135
	c-0.456-3.526,1.239-6.983,4.413-8.584c3.802-1.918,9.327-5.152,14.617-9.872c5.891-5.256,9.347-10.799,11.299-14.868
	c1.681-3.504,5.545-5.486,9.311-4.525c29.076,7.416,48.871,22.543,56.053,28.719c1.928,1.658,3.039,4.103,2.841,6.639
	C121.719,306.097,100.368,326.193,74.323,326.193z"></path>
<path style="fill:#E6AF78;" d="M120.878,273.927c-7.181-6.176-26.977-21.303-56.053-28.719c-3.766-0.961-7.63,1.021-9.311,4.525
	c-1.478,3.082-3.921,7.008-7.546,11.016c-0.001,0.01-0.004,0.018-0.005,0.028c-1.125,1.275-2.323,2.553-3.747,3.825
	c-5.29,4.721-10.815,7.954-14.617,9.872c-3.174,1.601-4.868,5.059-4.413,8.585c2.825,21.855,19.927,39.251,41.625,42.569
	c-9.887-6.726-17.262-15.976-17.262-32.466v-11.776c1.876-1.385,3.765-2.766,5.663-4.46c4.59-4.096,8.597-8.833,11.81-13.933
	c22.243,6.941,37.323,18.502,43.04,23.418c1.565,1.372,5.449,4.952,9.993,9.215c1.955-4.705,3.248-9.753,3.663-15.058
	C123.917,278.031,122.806,275.586,120.878,273.927z"></path>
<path style="fill:#C7CFE2;" d="M5.034,369.859C1.853,374.081,0,379.26,0,384.745v48.802c0,4.561,3.697,8.258,8.258,8.258h24.774
	v-41.61c0-5.017-2.281-9.763-6.199-12.897L5.034,369.859z"></path>
<path style="fill:#FF507D;" d="M374.643,351.318l-69.095-25.126L256,342.709l-49.548-16.516l-69.095,25.126
	c-13.054,4.747-21.744,17.153-21.744,31.043v51.186c0,4.56,3.697,8.258,8.258,8.258h264.258c4.561,0,8.258-3.698,8.258-8.258
	v-51.186C396.387,368.471,387.698,356.065,374.643,351.318z"></path>
<polygon style="fill:#707487;" points="247.349,359.226 239.484,441.805 272.516,441.805 264.651,359.226 "></polygon>
<path style="fill:#5B5D6E;" d="M264.67,370.571h-17.34c-3.193,0-5.781-2.588-5.781-5.781v-22.081h28.901v22.081
	C270.451,367.982,267.863,370.571,264.67,370.571z"></path>
<path style="fill:#D23C69;" d="M387.498,359.855c5.576,5.985,8.889,13.956,8.889,22.506v51.186c0,4.561-3.697,8.258-8.258,8.258
	h-41.29v-27.608c0-8.761,3.48-17.163,9.675-23.357L387.498,359.855z"></path>
<path style="fill:#5A4146;" d="M346.839,155.889V86.709c0-9.122-7.395-16.516-16.516-16.516h-99.097
	c-36.486,0-66.065,29.578-66.065,66.065v19.631c0,8.876,1.431,17.694,4.238,26.114l2.749,8.247c0.842,2.526,1.271,5.171,1.271,7.834
	v4.238H338.58v-4.238c0-2.663,0.429-5.308,1.271-7.834l2.749-8.247C345.408,173.582,346.839,164.764,346.839,155.889z"></path>
<path style="fill:#694B4B;" d="M206.452,103.741c0,18.528,15.02,33.548,33.548,33.548h4.645l2.242,65.032h91.693v-4.238
	c0-2.663,0.429-5.308,1.271-7.834l2.749-8.247c2.807-8.42,4.238-17.238,4.238-26.114V86.709c0-9.122-7.395-16.516-16.516-16.516H240
	C221.472,70.193,206.452,85.213,206.452,103.741z"></path>
<rect x="206.45" y="268.39" style="fill:#E6AF78;" width="99.1" height="74.32"></rect>
<path style="fill:#D29B6E;" d="M206.452,296.31c14.588,8.451,31.477,13.366,49.548,13.366s34.961-4.915,49.548-13.366v-27.924
	h-99.097L206.452,296.31L206.452,296.31z"></path>
<g>
	<path style="fill:#D23C69;" d="M256,342.709l-26.338,26.338c-3.54,3.54-9.391,3.141-12.417-0.847l-27.309-35.984l7.143-15.053
		c2.108-4.442,7.606-6.07,11.792-3.49L256,342.709z"></path>
	<path style="fill:#D23C69;" d="M256,342.709l26.338,26.338c3.54,3.54,9.391,3.141,12.417-0.847l27.309-35.984l-7.143-15.053
		c-2.108-4.442-7.606-6.07-11.792-3.49L256,342.709z"></path>
</g>
<path style="fill:#F0C087;" d="M256,293.161L256,293.161c-45.608,0-82.581-36.973-82.581-82.581v-9.675
	c0-4.38,1.74-8.581,4.837-11.679l6.841-6.841c3.097-3.097,4.837-7.298,4.837-11.679V150.91c0-3.824,2.568-7.146,6.289-8.025
	c19.531-4.613,80.308-15.54,121.669,14.88c2.686,1.975,4.171,5.22,4.171,8.554v4.387c0,4.38,1.74,8.581,4.837,11.679l6.841,6.841
	c3.097,3.097,4.837,7.298,4.837,11.679v9.675C338.581,256.188,301.608,293.161,256,293.161z"></path>
<path style="fill:#E6AF78;" d="M317.893,157.766c-29.09-21.395-67.731-22.321-94.925-19.392
	c-11.471,1.235-20.949,3.144-26.743,4.512c-3.721,0.879-6.289,4.201-6.289,8.025v19.795c0,4.381-1.74,8.582-4.838,11.68
	l-6.841,6.841c-3.098,3.098-4.838,7.299-4.838,11.68v9.674c0,42.224,31.71,76.985,72.602,81.92
	c-14.249-14.839-23.054-34.948-23.054-57.146v-60.361c0-8.369,6.223-15.363,14.526-16.404c19.818-2.485,56.116-3.979,84.57,12.118
	v-4.388C322.065,162.986,320.577,159.74,317.893,157.766z"></path>
<path style="fill:#D23C69;" d="M124.502,359.855c-5.576,5.985-8.889,13.956-8.889,22.506v51.186c0,4.561,3.697,8.258,8.258,8.258
	h41.29v-27.608c0-8.761-3.48-17.163-9.675-23.357L124.502,359.855z"></path>
<g>
</g>

</svg>    </div>
    </div>
    <div class="col-8">
    <div class="numbers">
    
    <h5 class="font-weight-bolder mb-0">
        Client
    <!-- <span class="text-success text-sm font-weight-bolder">+5%</span> -->
    </h5>
    </div>
    </div>
    
    </div>
    </div>
    </div>
    </div>
    </div>
    
    <div class="main-content position-relative bg-gray-100 max-height-vh-100 h-100 ps ps--active-y">


<div class="container-fluid">
<div class="page-header min-height-300 border-radius-xl mt-4" style="background-image: url('/img/curved-images/curved0.jpg'); background-position-y: 50%;">
<span class="mask bg-gradient-primary opacity-6"></span>
</div>
<div class="card card-body blur shadow-blur mx-4 mt-n6 overflow-hidden">
<div class="row gx-4">

<div class="col-auto my-auto">
<div class="h-100">
<h5 class="mb-1">

    John Michael
</h5>
<p class="mb-0 font-weight-bold text-sm">
CEO of Marketing Agency
</p>
</div>
</div>

</div>
</div>
</div>
<div class="container-fluid py-4">
<div class="row">


<!-- Company Information -->
<div class="col-12 col-xl-6">
<div class="card h-100">
<div class="card-header pb-0 p-3">
<div class="row">
<div class="col-md-8 d-flex align-items-center">
<h6 class="mb-0">Company Information</h6>
</div>
<div class="col-md-4 text-end">
<router-link  to="">
<i class="fas fa-user-edit text-secondary text-sm" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Add Month" data-bs-original-title="Edit Profile"></i>
</router-link>
</div>
</div>
</div>
<div class="card-body p-3">

<ul class="list-group" id="zip_file">
    <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark">Email:</strong> &nbsp; abc@domain.com</li>

<li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Location:</strong> &nbsp; USA</li>
<li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Phone number:</strong> &nbsp; +21062358</li>
<li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Company Profile:</strong> &nbsp;<router-link to="!#"> <svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></router-link> 
</li>

</ul>
</div>

</div>
</div>
<!-- Title Page -->
<div class="col-12 col-xl-6">
<div class="card h-100">
<div class="card-header pb-0 p-3">
<div class="row">
<div class="col-md-8 d-flex align-items-center">
<h6 class="mb-0">Social Media Accounts</h6>

</div>
<div class="col-md-4 text-end">
<router-link  to="">
<i class="fas fa-user-edit text-secondary text-sm" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Add Month" data-bs-original-title="Edit Profile"></i>
</router-link>
</div>
</div>
</div>
<div class="card-body p-3">

<ul class="list-group">
    <li class="list-group-item border-0 ps-0 pb-0">

<a class="btn btn-facebook btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;" style="
    scale: 1.6;
">
<i class="fab fa-facebook fa-lg"></i>
</a>
</li>
<li class="list-group-item border-0 ps-0 pb-0">
    
<a class="btn btn-twitter btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;" style="
    scale: 1.6;
">
<i class="fab fa-twitter fa-lg"></i>
</a>
</li>
<li class="list-group-item border-0 ps-0 pb-0">
<a class="btn btn-instagram btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;" style="
    scale: 1.6;
">
<i class="fab fa-instagram fa-lg"></i>
</a>
</li>
</ul>
</div>

</div>
</div>
</div>
<br>
<hr>
<div class="row">

<!-- Salary Statement -->
<div class="col-12 col-xl-12">
<div class="card h-100">
<div class="card-header pb-0 p-3">
<div class="row">
<div class="col-md-8 d-flex align-items-center">
<h6 class="mb-0">Projects</h6>
</div>
<div class="col-md-4 text-end">
<router-link  to="">
<i class="fa-solid fa-plus text-secondary text-sm" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Add Month" data-bs-original-title="Edit Profile"></i>
</router-link>
</div>
</div>
</div>
<div class="card-body p-3">

    <table class="table align-items-center mb-0">
<thead>
<tr>

<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Project Name</th>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Description</th>

<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Month</th>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Year</th>

<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">File</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<div class="d-flex px-2 py-1">

<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm">Project</h6>
</div>
</div>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">that project </p>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">4</p>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm">2024</span>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm"><svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></span>
</td>


</tr>
<!-- Second month -->
<tr>
<td>
<div class="d-flex px-2 py-1">

<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm">Project</h6>
</div>
</div>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">that project </p>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">4</p>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm">2024</span>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm"><svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></span>
</td>


</tr>
<!-- Third Month -->
<tr>
<td>
<div class="d-flex px-2 py-1">

<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm">Project</h6>
</div>
</div>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">that project </p>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">4</p>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm">2024</span>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm"><svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></span>
</td>


</tr>
<!-- fourth  month -->
<tr>
<td>
<div class="d-flex px-2 py-1">

<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm">Project</h6>
</div>
</div>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">that project </p>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">4</p>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm">2024</span>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm"><svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></span>
</td>


</tr>

<tr>
<td>
<div class="d-flex px-2 py-1">

<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm">Project</h6>
</div>
</div>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">that project </p>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">4</p>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm">2024</span>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm"><svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></span>
</td>


</tr>

<tr>
<td>
<div class="d-flex px-2 py-1">

<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm">Project</h6>
</div>
</div>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">that project </p>
</td>
<td>
<p class="text-xs font-weight-bold mb-0">4</p>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm">2024</span>
</td>
<td class="align-middle text-left text-sm">
<span class="mb-0 text-sm"><svg id="fi_9496565" enable-background="new 0 0 512 512"  viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><g><g clip-rule="evenodd" fill-rule="evenodd"><path d="m168.579 0h173.408l153.07 153.07v293.997c0 35.729-29.204 64.933-64.933 64.933h-261.545c-35.7 0-64.903-29.203-64.903-64.933v-382.164c0-35.699 29.203-64.903 64.903-64.903z" fill="#008bf5"></path><path d="m341.987 0 153.07 153.07h-136.566c-9.101 0-16.504-7.433-16.504-16.504z" fill="#006fc4"></path><path d="m31.193 218.003h352.638c7.842 0 14.251 6.408 14.251 14.251v129.368c0 7.842-6.408 14.28-14.251 14.28h-352.638c-7.842 0-14.251-6.438-14.251-14.28v-129.368c.001-7.842 6.409-14.251 14.251-14.251z" fill="#006fc4"></path></g><path d="m180.27 341.227c0 4.566-3.701 8.267-8.267 8.267h-53.199c-2.979 0-5.728-1.603-7.195-4.196s-1.425-5.774.109-8.328l45.675-76.025h-38.589c-4.566 0-8.266-3.701-8.266-8.267s3.701-8.266 8.266-8.266h53.199c2.979 0 5.728 1.603 7.195 4.196s1.425 5.774-.109 8.328l-45.675 76.025h38.589c4.566-.001 8.267 3.7 8.267 8.266zm124.217-61.949v1.141c0 19.225-15.641 34.865-34.866 34.865h-18.332v25.942c0 4.566-3.701 8.267-8.266 8.267s-8.266-3.701-8.266-8.267v-34.208-10.739-43.601c0-4.566 3.701-8.266 8.266-8.266h26.599c19.225 0 34.865 15.641 34.865 34.866zm-16.533 0c0-10.109-8.224-18.333-18.333-18.333h-18.332v35.334 2.473h18.332c10.109 0 18.333-8.224 18.333-18.332zm-78.993-34.866c-4.566 0-8.266 3.701-8.266 8.266v88.548c0 4.566 3.701 8.267 8.266 8.267 4.566 0 8.266-3.701 8.266-8.267v-88.548c0-4.565-3.7-8.266-8.266-8.266z" fill="#fff"></path></g></svg></span>
</td>


</tr>
</tbody>
</table>
</div>

</div>
</div>
</div>
</div>
</div>

    </main>
    </template>
    
    <script>
    export default {
    
    }
    </script>
    
    <style lang="scss">
    .management{
 
  
    }
    #zip_file{
        svg{
            width: 30px;
        }
    }
    </style>