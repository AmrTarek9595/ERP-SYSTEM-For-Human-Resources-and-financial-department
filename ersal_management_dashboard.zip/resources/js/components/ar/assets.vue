<template>

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg " style="direction: rtl;">
    
    
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
    <div class="container-fluid py-1 px-3">
 
    
        <div style="text-align: center;display: block;" class="container-fluid py-1 px-3">
            <h3 >الإدارة المالية</h3>
        </div>
   
    <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
   
    <ul class="navbar-nav  justify-content-end">
  
    <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
    <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
    <div class="sidenav-toggler-inner">
    <i class="sidenav-toggler-line"></i>
    <i class="sidenav-toggler-line"></i>
    <i class="sidenav-toggler-line"></i>
    </div>
    </a>
    </li>
    
    
    </ul>
    </div>
    </div>
    </nav>
    <div class="row container-fluid py-4">
    
    
    
    <div class="col-xl-3 col-sm-6">
    <div class="card">
    <div class="card-body p-3">
    <div class="row">
    <div class="col-4 text-end">
    <div class="icon icon-shape shadow text-center border-radius-md">
<svg id="Layer_1_1_" enable-background="new 0 0 64 64"  viewBox="0 0 64 64"  xmlns="http://www.w3.org/2000/svg"><path d="m56 34h-45c-1.657 0-3-1.343-3-3h51c0 1.657-1.343 3-3 3z" fill="#e8e5df"/><path d="m15 32h12c2.761 0 5-2.239 5-5v-3.067c0-4.933-3.955-11.933-5.133-11.933h-11.734c-1.178 0-5.133 7-5.133 11.933v3.067c0 2.761 2.239 5 5 5z" fill="#febe07"/><path d="m28.77 4.281-2.09 1.045c-.317.159-.702.068-.915-.216l-1.325-1.767c-.268-.357-.79-.394-1.105-.079l-1.738 1.738c-.316.316-.837.279-1.105-.079l-1.185-1.58c-.268-.357-.79-.394-1.105-.079l-2.03 2.03c-.188.188-.464.26-.72.187l-3.035-.867c-.625-.178-1.157.486-.845 1.057l3.428 6.329h12l2.775-6.781c.262-.627-.397-1.241-1.005-.938z" fill="#febe07"/><path d="m27 32c2.761 0 5-2.239 5-5v-3.067c0-4.933-3.955-11.933-5.133-11.933h-11.734c-.668 0 6.36.431 9.867 6 2.677 4.251 2 14 2 14z" fill="#e3a800"/><path d="m28.77 4.281-1.414.707c-2.747 2.756-6.199 4.722-9.994 5.671l-2.72.68.358.661h12l2.775-6.781c.262-.627-.397-1.241-1.005-.938z" fill="#e3a800"/><path d="m29 30h-12c-2.761 0-5-2.239-5-5v-3.067c0-3.292 1.76-7.495 3.282-9.933h-.149c-1.178 0-5.133 7-5.133 11.933v3.067c0 2.761 2.239 5 5 5h12c1.897 0 3.527-1.069 4.375-2.625-.71.386-1.511.625-2.375.625z" fill="#e3a800"/><path d="m35 4h10v28h-10z" fill="#cbe6fe"/><path d="m45 16-4 4-4 4h2v8h6z" fill="#a9c6eb"/><path d="m29.3 16h-3.3v16h9v-16z" fill="#cbe6fe"/><path d="m47 27h4v5h-4z" fill="#a9c6eb"/><path d="m57.707 30c-1.046 0-2.003.591-2.471 1.527l-.236.473-3 6-7 3c0-2.209-1.791-4-4-4h-14.398c-5.595 0-11.05 1.748-15.602 5v15h23.606c4.832 0 9.566-1.358 13.663-3.919 6.195-3.871 10.456-10.188 11.725-17.381l.434-2.458c.298-1.691-1.003-3.242-2.721-3.242z" fill="#ffe5cf"/><path d="m55 24h-12v8h4v-5h4v5h4z" fill="#cbe6fe"/><path d="m57 24-8-8-4 4-4 4z" fill="#e3a800"/><path d="m32 16h3v16h-3z" fill="#a9c6eb"/><path d="m13.079 40.669c-.709.414-1.407.851-2.079 1.331v15h23.606l-5.675-.525c-8.466-.784-15.065-7.496-15.852-15.806z" fill="#f5dcc7"/><path d="m23 20v-1c0-.552-.447-1-1-1h-1v-1h-2v1h-1c-.553 0-1 .448-1 1v3c0 .552.447 1 1 1h3v1h-4v1c0 .552.447 1 1 1h1v1h2v-1h1c.553 0 1-.448 1-1v-3c0-.552-.447-1-1-1h-3v-1z" fill="#fefefe"/><path d="m41 47h-16v-2h16c1.654 0 4-2.346 4-4l1 1c0 2.757-2.243 5-5 5z" fill="#f5dcc7"/><g fill="#2b67b3"><path d="m38 7h1v2h-1z"/><path d="m41 7h1v2h-1z"/><path d="m38 11h1v2h-1z"/><path d="m41 11h1v2h-1z"/><path d="m38 15h1v2h-1z"/><path d="m41 15h1v2h-1z"/><path d="m29 19h1v2h-1z"/><path d="m32 19h1v2h-1z"/><path d="m29 23h1v2h-1z"/><path d="m32 23h1v2h-1z"/><path d="m29 27h1v2h-1z"/><path d="m32 27h1v2h-1z"/><path d="m38 19h1v2h-1z"/><path d="m41 19h1v2h-1z"/></g><path d="m53 4h2v2h-2z" fill="#febe07"/><path d="m55 2h2v2h-2z" fill="#febe07"/><path d="m57 4h2v2h-2z" fill="#febe07"/><path d="m55 6h2v2h-2z" fill="#febe07"/><path d="m60 9h2v2h-2z" fill="#febe07"/><path d="m53 12h2v2h-2z" fill="#febe07"/><path d="m2 11h2v2h-2z" fill="#febe07"/><path d="m4 9h2v2h-2z" fill="#febe07"/><path d="m6 11h2v2h-2z" fill="#febe07"/><path d="m4 13h2v2h-2z" fill="#febe07"/><path d="m2 19h2v2h-2z" fill="#febe07"/><path d="m6 2h2v2h-2z" fill="#febe07"/><path d="m10 37h-6c-.552 0-1 .448-1 1v22c0 .552.448 1 1 1h6c.552 0 1-.448 1-1v-22c0-.552-.448-1-1-1z" fill="#2b67b3"/><path d="m7 44c-.552 0-1-.448-1-1v-1c0-.552.448-1 1-1 .552 0 1 .448 1 1v1c0 .552-.448 1-1 1z" fill="#fefefe"/></svg>
    </div>
    </div>
    <div class="col-8">
    <div class="numbers">
    
    <h5 class="font-weight-bolder mb-0">
        الإدارة المالية
    <!-- <span class="text-success text-sm font-weight-bolder">+5%</span> -->
    </h5>
    </div>
    </div>
    
    </div>
    </div>
    </div>
    </div>
    </div>
    
    <div class="container-fluid py-4">
        <div class="container">
    <div class="row" style="
    justify-content: center;
">
        <div class="col-lg-3 col-md-4 col-sm-6">
            <router-link to="/ar/fingerprintforaccountant">
            <div class="serviceBox">
                <h3 class="title">بصمة الموظفين</h3>
                
                <div class="service-icon">
                    <span><i class="fa-solid fa-fingerprint"></i></span>
                </div>
            </div>
        </router-link>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <router-link to="/ar/custody/asset">
            <div class="serviceBox">
                <h3 class="title">العهده المالية</h3>
                
                <div class="service-icon">
                    <span><i class="fa-brands fa-accusoft"></i></span>
                </div>
            </div>
        </router-link>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <router-link to="/ar/static/asset">
            <div class="serviceBox">
                <h3 class="title">الأصول الثابته</h3>
                
                <div class="service-icon">
                    <span><i class="fa-solid fa-chart-column"></i></span>
                </div>
            </div>
            </router-link>
        </div>
      
    </div>
</div>


</div>

    </main>
    </template>
    
    <script>
    export default {
    
    }
    </script>
    
    <style lang="scss">
    .management{
        .row{
            .col-lg-6{
                height: 20rem;
                .DP{
                    background-size: 100% 100%;
        background-repeat: no-repeat;
    
                }
            }
        }
    }
    :root{ --main-color: #087eff; }
.demo{ background-color: #eee; }
.serviceBox{
    color: #fff;
    background-color: #fff;
    font-family: 'Poppins', sans-serif;
    text-align: center;
    padding: 25px 15px 35px;
    border: 8px solid #0890ff29;
    border-radius: 30px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    position: relative;
}
.serviceBox .service-icon{
    color: var(--main-color);
    background:var(--white);
    font-size: 40px;
    line-height: 40px;
    width: 80px;
    height: 80px;
    line-height: 80px;
    border-radius: 50px;
    box-shadow: 0 0 30px var(--main-color);
    margin: 0 auto 30px;
}
.serviceBox .title{
    color: var(--main-color);
    font-size: 18px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin: 0 0 10px;
}

.serviceBox.pink{ --main-color: #F1679A; }
.serviceBox.green{ --main-color: #10BE81; }
.serviceBox.blue{ --main-color: #02A7B6; }
@media only screen and (max-width: 1199px){
    .serviceBox{ margin: 0 0 30px; }
}
    </style>